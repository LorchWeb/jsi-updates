<?php

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;

class PlgSystemJsiInstallerScript
{
    public function preflight($type, $parent): bool
    {
        if ($type !== 'uninstall' && (version_compare(PHP_VERSION, '8.1', '<')
            || version_compare(JVERSION, '5.0', '<') || version_compare(JVERSION, '7.0', '>='))) {
            Factory::getApplication()->enqueueMessage(Text::_('PLG_SYSTEM_JSI_REQUIREMENTS'), 'error');
            return false;
        }

        return true;
    }
}
