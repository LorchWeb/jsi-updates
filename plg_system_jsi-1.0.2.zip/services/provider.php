<?php

defined('_JEXEC') or die;

use Joomla\CMS\Extension\PluginInterface;
use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;
use Joomla\Event\DispatcherInterface;
use Lorch\Plugin\System\Jsi\Extension\Jsi;

return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->set(PluginInterface::class, static function (Container $container): Jsi {
            $config = (array) PluginHelper::getPlugin('system', 'jsi');
            $plugin = version_compare(JVERSION, '5.4', '<')
                ? new Jsi($container->get(DispatcherInterface::class), $config)
                : new Jsi($config);
            $plugin->setApplication(Factory::getApplication());
            return $plugin;
        });
    }
};
