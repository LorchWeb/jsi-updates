<?php

declare(strict_types=1);

namespace Lorch\Plugin\System\Jsi\Extension;

use Joomla\CMS\Document\HtmlDocument;
use Joomla\CMS\Log\Log;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\Event\EventInterface;
use Joomla\Event\SubscriberInterface;
use Lorch\Plugin\System\Jsi\Json\Snippet;
use Lorch\Plugin\System\Jsi\Routing\PageMatcher;

defined('_JEXEC') or die;

final class Jsi extends CMSPlugin implements SubscriberInterface
{
    private bool $rendered = false;

    public static function getSubscribedEvents(): array
    {
        return [
            'onContentPrepareForm' => 'prepareForm',
            'onBeforeCompileHead' => 'renderSnippets',
        ];
    }

    public function prepareForm(EventInterface $event): void
    {
        if (!$this->getApplication()->isClient('administrator')) {
            return;
        }

        $form = $event->getArgument('subject');

        if ($form->getName() !== 'com_menus.item') {
            return;
        }

        $data = $event->getArgument('data');
        $clientId = is_array($data) ? ($data['client_id'] ?? 0) : ($data->client_id ?? 0);

        if ((int) $clientId !== 0 || (int) $form->getValue('client_id', null, 0) !== 0) {
            return;
        }

        $this->loadLanguage();
        $form->loadFile(dirname(__DIR__, 2) . '/forms/menu.xml');
    }

    public function renderSnippets(EventInterface $event): void
    {
        $app = $this->getApplication();

        if ($this->rendered || !$app->isClient('site')) {
            return;
        }

        $document = $app->getDocument();

        if (!$document instanceof HtmlDocument || $app->getInput()->getCmd('tmpl', '') !== ''
            || !in_array($app->getInput()->getCmd('format', 'html'), ['', 'html'], true)
            || $app->getInput()->getCmd('task', '') !== '' || http_response_code() >= 400
        ) {
            return;
        }

        foreach ($app->getHeaders() as $header) {
            if (strtolower($header['name']) === 'status' && (int) $header['value'] >= 400) {
                return;
            }
        }

        $this->rendered = true;

        if ((bool) $this->params->get('jsi_global_enabled', 0)) {
            $this->append($document, (string) $this->params->get('jsi_global_jsonld', ''), 'global');
        }

        $menu = $app->getMenu();
        $active = $menu->getActive();
        $seen = [];

        while ($active !== null && $active->type === 'alias') {
            if (isset($seen[$active->id])) {
                $this->debug('Menü-Alias enthält einen Zyklus.');
                return;
            }

            $seen[$active->id] = true;
            $active = $menu->getItem((int) $active->getParams()->get('aliasoptions', 0));
        }

        if ($active === null || $active->type !== 'component' || !$active->getParams()->get('jsi_enabled', 0)) {
            return;
        }

        if ($active->language !== '*' && $active->language !== $app->getLanguage()->getTag()) {
            return;
        }

        try {
            $target = Route::link('site', 'index.php?Itemid=' . (int) $active->id, false);
            $matches = (new PageMatcher())->matches(
                $target,
                Uri::getInstance()->toString(['scheme', 'host', 'port', 'path', 'query']),
                $active->query,
                $app->getInput()->getArray()
            );
        } catch (\Throwable $error) {
            $this->debug('Seitenziel nicht auflösbar; Menüpunkt ' . (int) $active->id . '.');
            return;
        }

        if (!$matches) {
            $this->debug('Seitenziel stimmt nicht überein; Menüpunkt ' . (int) $active->id . '.');
            return;
        }

        $this->append($document, (string) $active->getParams()->get('jsi_jsonld', ''), 'menu-' . (int) $active->id);
    }

    private function append(HtmlDocument $document, string $source, string $name): void
    {
        try {
            $json = (new Snippet())->encode($source);
        } catch (\JsonException | \InvalidArgumentException $error) {
            $this->debug('Ungültiges JSON-LD übersprungen: ' . $name . '.');
            return;
        }

        if ($json !== '') {
            $document->addCustomTag('<script type="application/ld+json" id="jsi-' . $name . '">' . $json . '</script>');
        }
    }

    private function debug(string $message): void
    {
        if (!(bool) $this->params->get('jsi_debug', 0)) {
            return;
        }

        try {
            Log::addLogger(['text_file' => 'jsi.php'], Log::ALL, ['jsi']);
            Log::add($message, Log::DEBUG, 'jsi');
        } catch (\Throwable) {
            // Logging must not break the public page when the log directory is unwritable.
        }
    }
}
