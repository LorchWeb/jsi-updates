<?php

declare(strict_types=1);

namespace Lorch\Plugin\System\Jsi\Routing;

defined('_JEXEC') or die;

final class PageMatcher
{
    public function matches(string $targetUrl, string $currentUrl, array $menuQuery, array $routedQuery): bool
    {
        $target = parse_url($targetUrl);
        $current = parse_url($currentUrl);

        if ($target === false || $current === false || empty($menuQuery['option'])) {
            return false;
        }

        if (isset($target['host'], $current['host']) && strcasecmp($target['host'], $current['host']) !== 0) {
            return false;
        }

        if ($this->path($target['path'] ?? '/') !== $this->path($current['path'] ?? '/')) {
            return false;
        }

        // A menu can remain active on a different component view (for example a blog article).
        foreach ($menuQuery as $key => $value) {
            if (in_array($key, ['Itemid', 'lang'], true)) {
                continue;
            }

            if (!is_scalar($value) || !isset($routedQuery[$key]) || !is_scalar($routedQuery[$key])
                || (string) $value !== (string) $routedQuery[$key]
            ) {
                return false;
            }
        }

        foreach (['view', 'layout', 'id', 'catid', 'task', 'controller'] as $key) {
            if (!array_key_exists($key, $menuQuery) && !empty($routedQuery[$key])
                && !($key === 'layout' && $routedQuery[$key] === 'default')
            ) {
                return false;
            }
        }

        parse_str($target['query'] ?? '', $targetQuery);
        parse_str($current['query'] ?? '', $currentQuery);

        return $this->query($targetQuery) === $this->query($currentQuery);
    }

    private function path(string $path): string
    {
        // Decode only unreserved characters; encoded separators must remain distinct.
        $path = preg_replace_callback('/%[0-9a-f]{2}/i', static function (array $match): string {
            $character = rawurldecode($match[0]);
            return preg_match('/[a-z0-9._~-]/i', $character) ? $character : strtoupper($match[0]);
        }, $path);

        return rtrim($path, '/') ?: '/';
    }

    private function query(array $query): array
    {
        foreach ($query as $key => $value) {
            if ($key === 'Itemid' || preg_match('/^utm_/i', $key)
                || in_array($key, ['gclid', 'fbclid', 'msclkid'], true)
                || (in_array($key, ['start', 'limitstart', 'offset'], true) && is_scalar($value) && (string) $value === '0')
                || (in_array($key, ['page', 'p'], true) && is_scalar($value) && (string) $value === '1')
            ) {
                unset($query[$key]);
            }
        }

        ksort($query);
        return $query;
    }
}
