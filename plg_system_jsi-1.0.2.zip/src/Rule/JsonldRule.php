<?php

namespace Lorch\Plugin\System\Jsi\Rule;

use Joomla\CMS\Form\Form;
use Joomla\CMS\Form\FormRule;
use Joomla\CMS\Language\Text;
use Joomla\Registry\Registry;
use Lorch\Plugin\System\Jsi\Json\Snippet;

defined('_JEXEC') or die;

final class JsonldRule extends FormRule
{
    public function test(\SimpleXMLElement $element, $value, $group = null, ?Registry $input = null, ?Form $form = null)
    {
        try {
            if (!is_string($value) && $value !== null) {
                throw new \InvalidArgumentException('shape');
            }

            (new Snippet())->encode($value ?? '');
            return true;
        } catch (\JsonException | \InvalidArgumentException $error) {
            $key = $error instanceof \JsonException ? 'SYNTAX' : strtoupper($error->getMessage());
            $element['message'] = Text::_('PLG_SYSTEM_JSI_ERROR_' . $key);
            return false;
        }
    }
}
