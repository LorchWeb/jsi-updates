<?php

declare(strict_types=1);

namespace Lorch\Plugin\System\Jsi\Json;

defined('_JEXEC') or die;

final class Snippet
{
    public const MAX_BYTES = 65535;

    public function encode(string $source): string
    {
        $source = trim($source);

        if ($source === '') {
            return '';
        }

        if (strlen($source) > self::MAX_BYTES) {
            throw new \InvalidArgumentException('size');
        }

        $value = json_decode($source, false, 128, JSON_THROW_ON_ERROR);

        if (!$value instanceof \stdClass
            && (!is_array($value) || $value === [] || array_filter($value, static fn ($item) => !$item instanceof \stdClass) !== [])
        ) {
            throw new \InvalidArgumentException('shape');
        }

        // JSON is embedded in an HTML raw-text element, not an HTML attribute.
        return json_encode(
            $value,
            JSON_THROW_ON_ERROR | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE,
            128
        );
    }
}
